<?php
/* 
Template Name: Homepage
*/
get_header(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#4f6d7a"> <!-- Colore tema per browser mobile -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
    <title>Irene Orlandelli Psicologa – Il sostegno che ti guida a ritrovare l'equilibrio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#4f6d7a',
                        secondary: '#e0e6f1',
                        accent: '#9b8c7d',
                        light: '#f8f9fa',
                        dark: '#4a5568'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap');
        
        html, body {
            overflow-x: hidden;
        }

        body {
            font-family: 'Poppins', sans-serif;
            scroll-behavior: smooth;
            -webkit-text-size-adjust: 100%;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
            width: 100%;
        }
        
        h1, h2, h3, h4 {
            font-family: 'Playfair Display', serif;
        }
        
        .hero-gradient {
            background: linear-gradient(rgba(79, 109, 122, 0.8), rgba(224, 230, 241, 0.7));
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            transition: all 0.3s ease;
        }
        
        .quote-border {
            border-left: 4px solid #9b8c7d;
        }
        
        .cookies-banner {
            animation: slideUp 0.5s ease-out;
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .btn-animate:hover {
            background-position: right center;
        }
        
        input, textarea {
            transition: all 0.3s ease;
        }
        
        input:focus, textarea:focus {
            box-shadow: 0 0 0 3px rgba(155, 140, 125, 0.3);
            border-color: #9b8c7d;
        }
        
        .map-container {
            filter: grayscale(1) contrast(1.2) opacity(0.9);
        }

        /* WhatsApp Button Styles */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 20px;
            right: 20px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 24px;
            box-shadow: 2px 2px 3px #999;
            z-index: 100;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .whatsapp-float:hover {
            background-color: #128c7e;
            transform: scale(1.1);
            box-shadow: 0 8px 16px rgba(37, 211, 102, 0.3);
        }

        .whatsapp-tooltip {
            position: absolute;
            right: 70px;
            top: 50%;
            transform: translateY(-50%);
            background-color: #333;
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 14px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .whatsapp-tooltip::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 100%;
            margin-top: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent transparent #333;
        }

        .whatsapp-float:hover .whatsapp-tooltip {
            opacity: 1;
            visibility: visible;
        }

        @media (max-width: 768px) {
            .whatsapp-float {
                width: 55px;
                height: 55px;
                bottom: 15px;
                right: 15px;
                font-size: 22px;
            }
            
            .whatsapp-tooltip {
                right: 65px;
                font-size: 12px;
                padding: 6px 10px;
            }
        }

        /* Mobile contact section fixes */
        @media (max-width: 768px) {
            .contact-info-item {
                word-break: break-word;
                overflow-wrap: break-word;
            }
            
            .contact-grid {
                gap: 1rem;
            }
            
            .contact-form {
                padding: 1rem;
            }
            
            .contact-sidebar {
                padding: 1rem;
            }
        }
    </style>
</head>
<body class="bg-light text-dark">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-white shadow-sm">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2024/12/ordinepsicologilogo.webp" alt="Ordine degli Psicologi" class="h-12 w-auto">
                <a href="#" class="text-xl md:text-2xl font-bold text-primary">Irene Orlandelli Psicologa</a>
            </div>
            
            <nav class="hidden md:flex items-center space-x-8">
                <a href="#hero" class="font-medium hover:text-accent transition-colors">Home</a>
                <a href="#servizi" class="font-medium hover:text-accent transition-colors">Servizi</a>
                <a href="#chisono" class="font-medium hover:text-accent transition-colors">Chi Sono</a>
                <a href="#articoli" class="font-medium hover:text-accent transition-colors">Articoli</a>
                <a href="https://wa.me/393382733032" target="_blank" rel="noopener" class="inline-flex items-center bg-green-500 hover:bg-green-600 text-white font-medium px-4 py-2 rounded-lg transition-colors duration-300">
                    <i class="fab fa-whatsapp mr-2"></i>
                    Scrivimi su WhatsApp
                </a>
            </nav>
            
            <div class="md:hidden">
                <button id="menu-btn" class="text-primary focus:outline-none" style="min-height: 44px; min-width: 44px;">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-4 px-4">
            <div class="flex flex-col space-y-4">
                <a href="#hero" class="font-medium hover:text-accent transition-colors">Home</a>
                <a href="#servizi" class="font-medium hover:text-accent transition-colors">Servizi</a>
                <a href="#chisono" class="font-medium hover:text-accent transition-colors">Chi Sono</a>
                <a href="#articoli" class="font-medium hover:text-accent transition-colors">Articoli</a>
                <a href="https://wa.me/393382733032" target="_blank" rel="noopener" class="inline-flex items-center bg-green-500 hover:bg-green-600 text-white font-medium px-4 py-2 rounded-lg transition-colors duration-300 justify-center">
                    <i class="fab fa-whatsapp mr-2"></i>
                    Scrivimi su WhatsApp
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="hero" class="relative h-screen pt-16 md:pt-0">
        <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2024/12/IMG_8914.jpg" alt="Psicologa Irene Orlandelli" class="absolute inset-0 w-full h-full object-cover" loading="lazy" decoding="async">
        
        <div class="absolute inset-0 hero-gradient flex items-center">
            <div class="container mx-auto px-6 max-w-4xl">
                <div class="text-center md:text-left text-white">
                    <h1 class="text-4xl md:text-6xl font-bold leading-tight mb-6">Il sostegno che ti guida a ritrovare l'equilibrio</h1>
                    <p class="text-xl md:text-2xl mb-8">Affrontare le sfide della vita adulta può essere complesso: relazioni, obiettivi accademici e pressioni lavorative spesso mettono alla prova la nostra serenità.</p>
                    <div class="flex flex-col sm:flex-row justify-center md:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
                        <a href="#servizi" class="inline-block bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-8 rounded-lg transition-colors duration-300">Scopri i miei servizi</a>
                        <a href="#contatti" class="inline-block border-2 border-white hover:bg-white hover:text-primary text-white font-bold py-3 px-8 rounded-lg transition-colors duration-300">Prenota un appuntamento</a>
                    </div>
                </div>
            </div>
        </div>
        
        <a href="#servizi" class="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
        </a>
    </section>

    <!-- Servizi Section -->
    <section id="servizi" class="py-20 bg-secondary">
        <div class="container mx-auto px-6 max-w-6xl">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold mb-4 text-primary">Su cosa possiamo lavorare assieme</h2>
                <p class="text-xl max-w-3xl mx-auto">Ti supporto in un percorso di crescita e miglioramento, a superare ostacoli e ad affrontare le sfide quotidiane.</p>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                <!-- Service Card 1 -->
                <div class="bg-white rounded-xl shadow-lg p-6 service-card">
                    <div class="w-16 h-16 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mb-6">
                        <i class="fa-solid fa-handshake text-accent text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4 text-primary">Difficoltà relazionali nei Giovani Adulti</h3>
                    <p class="mb-4">Un supporto per navigare il complesso mondo delle relazioni.</p>
                    <p class="text-gray-600">Le relazioni sono il cuore della nostra vita: familiari, amicali, sentimentali o professionali. Per i giovani adulti, questo periodo di transizione può essere ricco di sfide...</p>
                </div>
                
                <!-- Service Card 2 -->
                <div class="bg-white rounded-xl shadow-lg p-6 service-card">
                    <div class="w-16 h-16 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mb-6">
                        <i class="fa-solid fa-graduation-cap text-accent text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4 text-primary">Difficoltà Universitarie</h3>
                    <p class="mb-4">Affronta gli studi con serenità e determinazione.</p>
                    <p class="text-gray-600">Affrontare l'università può essere una sfida complessa e stressante, soprattutto quando ci si trova a fronteggiare situazioni come il blocco negli studi...</p>
                </div>
                
                <!-- Service Card 3 -->
                <div class="bg-white rounded-xl shadow-lg p-6 service-card">
                    <div class="w-16 h-16 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mb-6">
                        <i class="fa-solid fa-briefcase text-accent text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4 text-primary">Ansia da Performance sul Lavoro</h3>
                    <p class="mb-4 italic">Affronta le sfide professionali con sicurezza e serenità.</p>
                    <p class="text-gray-600">Il mondo del lavoro può essere un contesto stimolante, ma anche fonte di pressione e stress, soprattutto per i giovani adulti...</p>
                </div>
                
                <!-- Service Card 4 -->
                <div class="bg-white rounded-xl shadow-lg p-6 service-card">
                    <div class="w-16 h-16 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mb-6">
                        <i class="fa-solid fa-cloud-sun text-accent text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4 text-primary">Depressione nei Giovani Adulti</h3>
                    <p class="mb-4 italic">Ritrova la serenità e valorizza il tuo potenziale.</p>
                    <p class="text-gray-600">La depressione è una sfida che molti giovani adulti tra i 25 e i 35 anni si trovano ad affrontare. Questo periodo della vita...</p>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="chisono" class="py-20 bg-white">
        <div class="container mx-auto px-6 max-w-6xl">
            <div class="grid md:grid-cols-2 gap-16 items-center">
                <div>
                    <div class="mb-10 pl-6 quote-border">
                        <p class="text-xl italic">"Mi vai bene così come sei, non ti chiedo niente. Non intendo curarti, modificarti, non ti critico né ti disapprovo. Sei tu a rivolgerti a me, a denunciare che qualcosa non va, a portarmi i tuoi bisogni inappagati."</p>
                        <p class="mt-4 font-semibold">Sergio Erba</p>
                    </div>
                    
                    <div>
                        <h2 class="text-3xl font-bold mb-6 text-primary">Le mie qualifiche da Psicoterapeuta</h2>
                        <p class="text-lg mb-4">Sono una psicologa ad orientamento psicoanalitico relazionale.</p>
                        <p class="mb-4">Ho sempre creduto che ogni persona abbia una storia unica da raccontare, fatta di emozioni, esperienze e sfide che meritano ascolto e comprensione. Il mio lavoro nasce dalla passione per aiutare le persone a riscoprire il loro equilibrio e a valorizzare le risorse interiori che spesso restano nascoste nei momenti di difficoltà.</p>
                        <p class="mb-6">Mi sono laureata in Psicologia Clinica a Milano e sto proseguendo la mia formazione in psicoterapia psicoanalitica relazionale. Sono iscritta all'Albo degli Psicologi della Lombardia.</p>
                        
                        <div class="bg-secondary p-6 rounded-lg">
                            <h3 class="text-xl font-bold mb-4 text-primary">Esperienze professionali</h3>
                            <ul class="space-y-3">
                                <li class="flex items-start">
                                    <i class="fa-solid fa-circle-check text-accent mr-3 mt-1"></i>
                                    <span>Collaboro attivamente con l'ambulatorio dell'ASST Fatebenefratelli</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fa-solid fa-circle-check text-accent mr-3 mt-1"></i>
                                    <span>Supporto a persone con disturbi dell'umore, depressione o ansia</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fa-solid fa-circle-check text-accent mr-3 mt-1"></i>
                                    <span>Formazione continua e aggiornamento professionale</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="relative">
                    <div class="relative z-10 rounded-2xl overflow-hidden shadow-xl">
                        <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2024/12/Irene-Orlandelli-Psicologa-scaled-e1734951656541-866x1024.jpg" alt="Irene Orlandelli Psicologa" class="w-full h-auto">
                    </div>
                    <div class="absolute -bottom-6 -right-6 bg-accent w-24 h-24 rounded-xl rotate-12 opacity-20"></div>
                    <div class="absolute top-6 -left-6 bg-primary w-20 h-20 rounded-xl rotate-12 opacity-20"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Articoli Section -->
    <section id="articoli" class="py-20 bg-secondary">
        <div class="container mx-auto px-6 max-w-6xl">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold mb-4 text-primary">Ultimi articoli</h2>
                <p class="text-xl">Esplora gli ultimi approfondimenti sulla salute psicologica</p>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Article Card 1 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2025/04/chatgpt.png" alt="ChatGPT psicologo" class="w-full h-56 object-cover">
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-3 text-primary">Può ChatGPT essere il tuo psicologo?</h3>
                        <p class="text-gray-600 mb-4">Negli ultimi anni l'intelligenza artificiale ha fatto passi da gigante, entrando a far parte della nostra quotidianità in modi sempre più sorprendenti...</p>
                        <a href="#" class="inline-flex items-center text-accent font-medium">
                            Leggi l'articolo
                            <i class="fa-solid fa-arrow-right ml-2 text-sm"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Article Card 2 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2025/01/cuore-spezzato.webp" alt="Sofferenza emotiva" class="w-full h-56 object-cover">
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-3 text-primary">Come gestire la sofferenza emotiva alla chiusura di una relazione?</h3>
                        <p class="text-gray-600 mb-4">La fine di una relazione può somigliare a una tempesta improvvisa: un turbinio di emozioni che ci travolge, lasciandoci disorientati e spesso sopraffatti...</p>
                        <a href="#" class="inline-flex items-center text-accent font-medium">
                            Leggi l'articolo
                            <i class="fa-solid fa-arrow-right ml-2 text-sm"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Article Card 3 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <img src="https://ireneorlandellipsicologa.it/wp-content/uploads/2024/12/immagine-per-lavoro.png" alt="Psicoterapia" class="w-full h-56 object-cover">
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-3 text-primary">Come può aiutare la Psicoterapia</h3>
                        <p class="text-gray-600 mb-4">Esploriamo insieme gli aspetti più rilevanti e i benefici principali che la psicoterapia può offrirti nella tua vita...</p>
                        <a href="#" class="inline-flex items-center text-accent font-medium">
                            Leggi l'articolo
                            <i class="fa-solid fa-arrow-right ml-2 text-sm"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-12">
                <a href="https://ireneorlandellipsicologa.it/blog/" class="inline-block bg-primary hover:bg-opacity-90 text-white font-bold py-3 px-8 rounded-lg transition-colors duration-300">Visita il blog</a>
            </div>
        </div>
    </section>

    <!-- Contatti Section -->
    <section id="contatti" class="py-20 bg-white">
        <div class="container mx-auto px-4 sm:px-6 max-w-6xl">
            <div class="grid md:grid-cols-2 gap-8 lg:gap-12 contact-grid">
                <div class="w-full">
                    <h2 class="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8 text-primary text-center md:text-left">Dove mi puoi trovare</h2>
                    
                    <div class="mb-8 sm:mb-10 space-y-6">
                        <div class="flex items-start contact-info-item">
                            <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-secondary flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                                <i class="fa-solid fa-location-dot text-primary text-sm sm:text-base"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3 class="text-lg sm:text-xl font-bold mb-1">Studio Professionale</h3>
                                <p class="text-base sm:text-lg break-words">Via Andrea Maria Ampere 81, Milano</p>
                                <p class="text-sm sm:text-base text-gray-600">Ricevo <strong>solo su appuntamento</strong>, in presenza o online</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start contact-info-item">
                            <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-secondary flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                                <i class="fa-solid fa-phone text-primary text-sm sm:text-base"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3 class="text-lg sm:text-xl font-bold mb-1">Telefono</h3>
                                <p class="text-base sm:text-lg break-all">+39 3382733032</p>
                                <a href="https://wa.me/393382733032" target="_blank" rel="noopener" class="mt-2 inline-flex items-center text-accent hover:text-accent-dark transition-colors text-sm sm:text-base">
                                    <i class="fab fa-whatsapp mr-2 text-base sm:text-lg"></i> Scrivimi su Whatsapp
                                </a>
                            </div>
                        </div>
                        
                        <div class="flex items-start contact-info-item">
                            <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-secondary flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                                <i class="fa-solid fa-envelope text-primary text-sm sm:text-base"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3 class="text-lg sm:text-xl font-bold mb-1">Email</h3>
                                <p class="text-base sm:text-lg break-all">ireneorlandelli.psicologa@gmail.com</p>
                            </div>
                        </div>
                    </div>
                    
                    <h3 class="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-primary text-center md:text-left">Contattami per una consulenza</h3>
                    <p class="mb-6 sm:mb-8 text-center md:text-left">Compila il modulo per richiedere informazioni, prenotare una seduta o fissare un incontro conoscitivo.</p>
                    
                    <form class="space-y-3 contact-form">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <label for="name" class="block font-medium mb-1 text-sm sm:text-base">Nome *</label>
                                <input type="text" id="name" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-accent text-sm sm:text-base">
                            </div>
                            <div>
                                <label for="surname" class="block font-medium mb-1 text-sm sm:text-base">Cognome</label>
                                <input type="text" id="surname" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-accent text-sm sm:text-base">
                            </div>
                        </div>
                        
                        <div>
                            <label for="email" class="block font-medium mb-1 text-sm sm:text-base">Email *</label>
                            <input type="email" id="email" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-accent text-sm sm:text-base">
                        </div>
                        
                        <div>
                            <label for="phone" class="block font-medium mb-1 text-sm sm:text-base">Telefono *</label>
                            <input type="tel" id="phone" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-accent text-sm sm:text-base">
                        </div>
                        
                        <div>
                            <label for="message" class="block font-medium mb-1 text-sm sm:text-base">Commento o messaggio *</label>
                            <textarea id="message" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-accent text-sm sm:text-base"></textarea>
                        </div>
                        
                        <div class="pt-2">
                            <button type="submit" class="w-full sm:w-auto bg-primary hover:bg-opacity-90 text-white font-bold py-2 px-6 rounded-lg transition-colors duration-300 flex items-center justify-center text-sm sm:text-base">
                                Invia richiesta
                                <i class="fa-solid fa-paper-plane ml-2"></i>
                            </button>
                        </div>
                    </form>
                </div>
                
                <div class="bg-secondary rounded-2xl p-4 sm:p-6 lg:p-8 contact-sidebar">
                    <div class="rounded-xl overflow-hidden shadow-lg mb-6 sm:mb-8">
                        <div class="map-container" style="height: 250px; background-color: #eee; display: flex; align-items: center; justify-content: center;">
                            <div class="text-center p-4">
                                <i class="fa-solid fa-map-location-dot text-3xl sm:text-4xl text-gray-500 mb-4"></i>
                                <p class="font-medium text-gray-600 text-sm sm:text-base">Mappa dello studio professionale</p>
                                <p class="text-gray-500 text-xs sm:text-sm break-words">Via Andrea Maria Ampere 81, Milano</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white p-4 sm:p-6 rounded-lg mb-6 sm:mb-8">
                        <h3 class="text-lg sm:text-xl font-bold mb-4 text-primary">Orari di ricevimento</h3>
                        <div class="space-y-3 sm:space-y-4">
                            <div class="flex justify-between pb-2 sm:pb-3 border-b text-sm sm:text-base">
                                <span>Lunedì - Venerdì</span>
                                <span class="font-medium">09:00 - 20:00</span>
                            </div>
                            <div class="flex justify-between pb-2 sm:pb-3 border-b text-sm sm:text-base">
                                <span>Sabato</span>
                                <span class="font-medium">10:00 - 15:00</span>
                            </div>
                            <div class="flex justify-between pb-2 sm:pb-3 border-b text-sm sm:text-base">
                                <span>Domenica</span>
                                <span class="font-medium">Chiuso</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-accent bg-opacity-10 p-4 sm:p-6 rounded-lg">
                        <h3 class="text-lg sm:text-xl font-bold mb-4 text-primary">Modalità di incontro</h3>
                        <div class="grid grid-cols-2 gap-3 sm:gap-4">
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                    <i class="fa-solid fa-user text-primary text-xs sm:text-sm"></i>
                                </div>
                                <span class="text-xs sm:text-sm">In studio</span>
                            </div>
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                    <i class="fa-solid fa-video text-primary text-xs sm:text-sm"></i>
                                </div>
                                <span class="text-xs sm:text-sm">Videochiamata</span>
                            </div>
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                    <i class="fa-solid fa-phone text-primary text-xs sm:text-sm"></i>
                                </div>
                                <span class="text-xs sm:text-sm">Telefono</span>
                            </div>
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                    <i class="fa-solid fa-comment text-primary text-xs sm:text-sm"></i>
                                </div>
                                <span class="text-xs sm:text-sm">Chat</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-primary text-white py-12">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 px-4 mx-auto max-w-[95vw]">
                <div>
                    <h3 class="text-xl font-bold mb-4">Irene Orlandelli Psicologa</h3>
                    <p class="mb-4 opacity-80">Il sostegno che ti guida a ritrovare l'equilibrio</p>
                    <div class="flex space-x-4">
                        <a href="#" class="opacity-80 hover:opacity-100">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="opacity-80 hover:opacity-100">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="opacity-80 hover:opacity-100">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Contatti</h3>
                    <ul class="space-y-3 opacity-80 break-words">
                        <li class="flex">
                            <i class="fa-solid fa-location-dot mr-3 mt-1 flex-shrink-0"></i>
                            <span class="break-words">Via Andrea Maria Ampere 81, Milano</span>
                        </li>
                        <li class="flex">
                            <i class="fa-solid fa-phone mr-3 mt-1 flex-shrink-0"></i>
                            <span>+39 3382733032</span>
                            <a href="https://wa.me/393382733032" target="_blank" rel="noopener" class="ml-2 text-accent">- Scrivimi su Whatsapp</a>
                        </li>
                        <li class="flex">
                            <i class="fa-solid fa-envelope mr-3 mt-1 flex-shrink-0"></i>
                            <span class="break-words">ireneorlandelli.psicologa@gmail.com</span>
                        </li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Link utili</h3>
                    <ul class="space-y-2 opacity-80">
                        <li><a href="#servizi" class="hover:underline">Servizi</a></li>
                        <li><a href="#chisono" class="hover:underline">Chi sono</a></li>
                        <li><a href="#articoli" class="hover:underline">Articoli</a></li>
                        <li><a href="https://ireneorlandellipsicologa.it/privacy-policy/" class="hover:underline">Privacy Policy</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Credits</h3>
                    <p class="opacity-80">Made with &#129505 by Pier</p>
                    <button id="cookies-btn" class="mt-4 bg-white bg-opacity-10 hover:bg-opacity-20 text-sm py-2 px-4 rounded-lg transition-colors">Preferenze cookie</button>
                </div>
            </div>
            
            <div class="border-t border-white border-opacity-20 mt-12 pt-8 text-center opacity-70 text-sm px-4 mx-auto max-w-[95vw]">
                <p>© 2023 Irene Orlandelli Psicologa. Tutti i diritti riservati.</p>
            </div>
        </div>
    </footer>

    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/393382733032" target="_blank" rel="noopener" class="whatsapp-float">
        <div class="whatsapp-tooltip">Contattami su WhatsApp</div>
        <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Cookies Banner -->
    <div id="cookies-banner" class="cookies-banner fixed bottom-0 left-0 right-0 bg-white shadow-lg z-50 px-6 py-6 hidden">
        <div class="max-w-6xl mx-auto">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-6 md:mb-0 md:mr-8">
                    <h3 class="text-lg font-bold text-primary mb-2">Utilizzo dei Cookie</h3>
                    <p class="text-sm opacity-80 max-w-2xl">Consideriamo i tuoi dati una tua proprietà e sosteniamo il tuo diritto alla privacy e alla trasparenza. Utilizziamo i cookie per migliorare la tua esperienza sul nostro sito web. Seleziona le tue preferenze di consenso.</p>
                </div>
                
                <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <button id="cookies-reject" class="px-6 py-3 border border-gray-300 rounded-lg text-sm">Rifiuta tutti</button>
                    <button id="cookies-accept" class="bg-primary text-white px-6 py-3 rounded-lg text-sm">Accetta tutti</button>
                    <button id="cookies-prefs" class="border border-primary text-primary px-6 py-3 rounded-lg text-sm">Personalizza</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Cookies Preferences Modal -->
    <div id="cookies-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white rounded-xl max-w-4xl w-full mx-4 p-8 relative">
            <button id="close-modal" class="absolute top-4 right-4 text-primary">
                <i class="fa-solid fa-times text-2xl"></i>
            </button>
            
            <h2 class="text-2xl font-bold text-primary mb-6">Preferenze di consenso</h2>
            
            <p class="mb-8">Utilizza gli interruttori qui sotto per specificare i tuoi scopi di condivisione dei dati per questo sito web.</p>
            
            <div class="space-y-8">
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-bold">Operazioni fondamentali</h3>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" checked disabled class="sr-only peer">
                            <div class="w-11 h-6 bg-primary rounded-full peer-checked:after:translate-x-full after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>
                    <p class="text-sm opacity-80 mb-2">Questo tipo di condivisione è necessario, affinché noi possiamo accedere ai dati di cui abbiamo bisogno per assicurarci che il sito web sia sicuro e funzioni correttamente.</p>
                    <p class="text-sm font-medium opacity-80">Dati a cui si accede:</p>
                    <ul class="text-sm opacity-80 list-disc pl-5 mt-2">
                        <li>Dati anonimi come il nome o la versione del browser</li>
                        <li>Dati pseudonimi come il token di autenticazione</li>
                    </ul>
                </div>
                
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-bold">Personalizzazione dei contenuti</h3>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer">
                            <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-primary peer-checked:after:translate-x-full after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>
                    <p class="text-sm opacity-80 mb-2">Quando viene abilitato, ci autorizzi a salvare le tue preferenze e a creare un profilo su di te, in modo da poterti offrire contenuti personalizzati.</p>
                    <p class="text-sm font-medium opacity-80">Dati a cui si accede:</p>
                    <ul class="text-sm opacity-80 list-disc pl-5 mt-2">
                        <li>Dati anonimi come il tipo, il modello e il sistema operativo del dispositivo</li>
                        <li>Dati pseudonimi come le preferenze di navigazione sul sito</li>
                        <li>Dati personali come il tuo indirizzo IP e la tua posizione</li>
                    </ul>
                </div>
                
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-bold">Ottimizzazione del sito</h3>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer">
                            <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-primary peer-checked:after:translate-x-full after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>
                    <p class="text-sm opacity-80 mb-2">Quando viene abilitato, questo ci consente di monitorare il tuo comportamento, così da poter analizzare e migliorare i servizi sul nostro sito web per tutti i visitatori.</p>
                    <p class="text-sm font-medium opacity-80">Dati a cui si accede:</p>
                    <ul class="text-sm opacity-80 list-disc pl-5 mt-2">
                        <li>Dati anonimi come l'indirizzo di un sito web precedentemente visitato (HTTP di presentazione)</li>
                        <li>Dati pseudonimi come gli identificatori di attività del sito web</li>
                        <li>Dati personali come la cronologia dei contenuti, delle ricerche e degli acquisti</li>
                    </ul>
                </div>
                
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-bold">Personalizzazione degli annunci</h3>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer">
                            <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-primary peer-checked:after:translate-x-full after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>
                    <p class="text-sm opacity-80 mb-2">Quando viene abilitato, ci autorizzi a condividere i tuoi dati con i nostri partner pubblicitari, che creano profili su di te su molteplici siti web.</p>
                    <p class="text-sm font-medium opacity-80">Dati a cui si accede:</p>
                    <ul class="text-sm opacity-80 list-disc pl-5 mt-2">
                        <li>Dati anonimi come i link di presentazione o di affiliazione</li>
                        <li>Dati pseudonimi come gli identificatori utilizzati per monitorare e profilare gli utenti</li>
                        <li>Dati personali come età, sesso e informazioni demografiche</li>
                    </ul>
                </div>
            </div>
            
            <div class="flex justify-end space-x-4 mt-10">
                <button id="modal-cancel" class="px-6 py-3 border border-gray-300 rounded-lg">Annulla</button>
                <button id="modal-save" class="bg-primary text-white px-6 py-3 rounded-lg">Salva preferenze</button>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const menuBtn = document.getElementById('menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
        
        // Cookies modal functionality
        const cookiesBanner = document.getElementById('cookies-banner');
        const cookiesBtn = document.getElementById('cookies-btn');
        const cookiesModal = document.getElementById('cookies-modal');
        const closeModal = document.getElementById('close-modal');
        const modalCancel = document.getElementById('modal-cancel');
        const modalSave = document.getElementById('modal-save');
        const cookiesAccept = document.getElementById('cookies-accept');
        const cookiesReject = document.getElementById('cookies-reject');
        const cookiesPrefs = document.getElementById('cookies-prefs');
        
        // Show cookies banner on page load
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                cookiesBanner.classList.remove('hidden');
            }, 2000);
        });
        
        // Show cookies modal
        cookiesBtn.addEventListener('click', () => {
            cookiesModal.classList.remove('hidden');
        });
        
        cookiesPrefs.addEventListener('click', () => {
            cookiesBanner.classList.add('hidden');
            cookiesModal.classList.remove('hidden');
        });
        
        // Close cookies modal
        closeModal.addEventListener('click', () => {
            cookiesModal.classList.add('hidden');
        });
        
        modalCancel.addEventListener('click', () => {
            cookiesModal.classList.add('hidden');
        });
        
        // Save cookies preferences
        modalSave.addEventListener('click', () => {
            cookiesModal.classList.add('hidden');
            cookiesBanner.classList.add('hidden');
        });
        
        // Accept all cookies
        cookiesAccept.addEventListener('click', () => {
            cookiesBanner.classList.add('hidden');
        });
        
        // Reject cookies
        cookiesReject.addEventListener('click', () => {
            cookiesBanner.classList.add('hidden');
        });
        
        // Optimized smooth scrolling with passive listeners
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    requestAnimationFrame(() => {
                        window.scrollTo({
                            top: target.offsetTop - 80,
                            behavior: 'smooth'
                        });
                        
                        // Close mobile menu if open
                        mobileMenu.classList.add('hidden');
                    });
                }
            }, {passive: false});
        });

        // Prevent zoom on double-tap (except for content inputs)
        document.addEventListener('dblclick', function(e) {
            if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) {
                e.preventDefault();
            }
        }, {passive: false});

        // Fast click handling
        document.addEventListener('touchstart', function() {}, {passive: true});
    </script>
</body>
</html>

<?php
get_footer();
?>
